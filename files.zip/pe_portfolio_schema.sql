-- =====================================================================
-- PE Portfolio Monitoring & Valuation Database
-- Schema + analysis queries for a simulated 8-company PE portfolio
-- =====================================================================

CREATE DATABASE IF NOT EXISTS pe_portfolio_monitoring;
USE pe_portfolio_monitoring;

-- ---------------------------------------------------------------------
-- 1. Portfolio Companies (deal-level master data)
-- ---------------------------------------------------------------------
CREATE TABLE PortfolioCompanies (
    CompanyID           INT PRIMARY KEY,
    CompanyName          VARCHAR(100) NOT NULL,
    Sector               VARCHAR(50) NOT NULL,
    Vintage              VARCHAR(10) NOT NULL,       -- quarter of initial investment
    InvestedCapital_mm   DECIMAL(10,2) NOT NULL,     -- $mm invested
    EntryEBITDA_mm        DECIMAL(10,2) NOT NULL,
    EntryMultiple_x       DECIMAL(5,2) NOT NULL,      -- EV/EBITDA at entry
    OwnershipPct          DECIMAL(5,4) NOT NULL,
    CovenantMaxLeverage   DECIMAL(5,2) NOT NULL       -- Net Debt / EBITDA covenant ceiling
);

-- ---------------------------------------------------------------------
-- 2. Quarterly Financials (operating performance, updated each quarter)
-- ---------------------------------------------------------------------
CREATE TABLE QuarterlyFinancials (
    RecordID        INT AUTO_INCREMENT PRIMARY KEY,
    CompanyID       INT NOT NULL,
    FiscalYear      INT NOT NULL,
    FiscalQuarter   VARCHAR(2) NOT NULL,             -- Q1..Q4
    Revenue_mm      DECIMAL(10,2) NOT NULL,
    EBITDA_mm       DECIMAL(10,2) NOT NULL,
    NetDebt_mm      DECIMAL(10,2) NOT NULL,
    Cash_mm         DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (CompanyID) REFERENCES PortfolioCompanies(CompanyID)
);

-- =====================================================================
-- ANALYSIS QUERIES
-- =====================================================================

-- A. Leverage ratio & covenant breach flag per company per quarter
SELECT
    pc.CompanyName,
    pc.Sector,
    qf.FiscalYear,
    qf.FiscalQuarter,
    qf.EBITDA_mm,
    qf.NetDebt_mm,
    ROUND(qf.NetDebt_mm / qf.EBITDA_mm, 2)                AS LeverageRatio_x,
    pc.CovenantMaxLeverage,
    CASE WHEN qf.NetDebt_mm / qf.EBITDA_mm > pc.CovenantMaxLeverage
         THEN 'BREACH' ELSE 'OK' END                       AS CovenantStatus
FROM QuarterlyFinancials qf
JOIN PortfolioCompanies pc ON pc.CompanyID = qf.CompanyID
ORDER BY pc.CompanyName, qf.FiscalYear, qf.FiscalQuarter;

-- B. EBITDA growth, quarter-over-quarter (%)
SELECT
    CompanyID,
    FiscalYear,
    FiscalQuarter,
    EBITDA_mm,
    ROUND(
        (EBITDA_mm - LAG(EBITDA_mm) OVER (PARTITION BY CompanyID ORDER BY FiscalYear, FiscalQuarter))
        / LAG(EBITDA_mm) OVER (PARTITION BY CompanyID ORDER BY FiscalYear, FiscalQuarter) * 100, 1
    ) AS EBITDA_QoQ_Growth_Pct
FROM QuarterlyFinancials;

-- C. Latest-quarter snapshot per company with implied current valuation & MOIC
--    (assumes exit multiple = entry multiple as a simplifying base case)
WITH LatestQuarter AS (
    SELECT CompanyID, MAX(FiscalYear * 10 + CAST(SUBSTRING(FiscalQuarter,2,1) AS UNSIGNED)) AS MaxKey
    FROM QuarterlyFinancials
    GROUP BY CompanyID
)
SELECT
    pc.CompanyName,
    pc.Sector,
    pc.InvestedCapital_mm,
    qf.EBITDA_mm                                             AS LatestEBITDA_mm,
    pc.EntryMultiple_x,
    ROUND(qf.EBITDA_mm * pc.EntryMultiple_x, 1)               AS ImpliedEV_mm,
    ROUND(qf.EBITDA_mm * pc.EntryMultiple_x - qf.NetDebt_mm, 1) AS ImpliedEquityValue_mm,
    ROUND((qf.EBITDA_mm * pc.EntryMultiple_x - qf.NetDebt_mm) * pc.OwnershipPct, 1) AS FundEquityValue_mm,
    ROUND(((qf.EBITDA_mm * pc.EntryMultiple_x - qf.NetDebt_mm) * pc.OwnershipPct) / pc.InvestedCapital_mm, 2) AS MOIC_x
FROM QuarterlyFinancials qf
JOIN LatestQuarter lq ON lq.CompanyID = qf.CompanyID
    AND (qf.FiscalYear * 10 + CAST(SUBSTRING(qf.FiscalQuarter,2,1) AS UNSIGNED)) = lq.MaxKey
JOIN PortfolioCompanies pc ON pc.CompanyID = qf.CompanyID
ORDER BY MOIC_x DESC;

-- D. Portfolio-level covenant breach summary (for a monitoring alert view)
SELECT
    pc.CompanyName,
    COUNT(*) AS BreachQuartersToDate
FROM QuarterlyFinancials qf
JOIN PortfolioCompanies pc ON pc.CompanyID = qf.CompanyID
WHERE qf.NetDebt_mm / qf.EBITDA_mm > pc.CovenantMaxLeverage
GROUP BY pc.CompanyName
ORDER BY BreachQuartersToDate DESC;
